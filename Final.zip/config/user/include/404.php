
<div class="container">
  <div class="d-flex justify-content-center">
  <h1>Not Found Page</h1>
  </div>
</div>