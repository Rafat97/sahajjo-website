# my-framework
Create own micro framework

when upload main site 
*config.json all value false
*default.json database value remove
*view/main.php update html
