<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<title>Error | Sahajjo</title>

	<?php include_once __DIR__ . '/include/script-head.php'; ?>
	<style>
	body{
		margin:0px;
	}
	</style>
	
</head>
<div class="d-flex align-items-center justify-content-center color2-bg" style="min-height: 100vh">
	<div class="d-flex align-items-center justify-content-center w-100 flex-wrap">
		<a class="" href="<?php echo base_url_route('dashboard/home'); ?>">
                <img src="<?php echo base_url_route('images/sahajjo.png'); ?>" class="logo-200" alt="">

            </a>
            <span class="color3-bg mx-3" style="height: 50px;width:4px"></span>
		<h2 class="color3 mb-0">Page Not Found!</h2>
	</div>
	
</div>