<footer class="footer-standard w-100">


		<div class="color2-bg color1 text-center padding-50px-tb text-center xs-padding-30px-tb">
			<div class="container">
				<div class="row">
					
					<div class="col-md-12">
						<a href="<?php echo base_url_route('about'); ?>" class="color1 color3-hover">About Us <span class="color1"> | </span> </a>
						
						<a href="<?php echo base_url_route('contact-us'); ?>" class="color1 color3-hover">Contact Us</a>
					</div>
					
					
					<div class="col-12 mt-4">
						<h6 class="text-center color1">  <a href="<?php echo base_url(); ?>" class="color1 color3-hover">Sahajjo <span class="color1"> | </span> </a> 2019</h6>
						
					</div>
					<!-- start copyright -->
				<!--	<div class="col-md-6 col-sm-6 col-xs-12 text-left text-small xs-text-center">&copy; 2019 Sahajjo | Designed by <a href="http://www.goliving.ca" target="_blank" class="text-dark-gray">Go Living Montreal Web Design</a></div>
					<div class="col-md-6 col-sm-6 col-xs-12 text-right text-small xs-text-center">
						<a href="javascript:void(0);" class="text-dark-gray">Terms and Conditions</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="javascript:void(0);" class="text-dark-gray">Privacy Policy</a>
					</div>
					<!-- end copyright
				</div> -->
			</div>
		</div>
	</footer>