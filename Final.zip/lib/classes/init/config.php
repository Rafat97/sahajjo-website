<?php
//

namespace Lib\Classes\Init;

use  Lib\Classes\DB;

class Config 
{
     


    function __construct($db){
       
        

        
    }
}
