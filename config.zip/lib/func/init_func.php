<?php

include_once "imp_fun.php";

global $fmw_database ;
global $fmw_serv_resp ;
global $fmw_config_val ;

$default_val = new Lib\Classes\Default_val();

$fmw_config_val = $default_val;
$fmw_database = $default_val->get_db_info();

if(!$fmw_database->isConnection()){
    echo "Please Connect Database first";
    exit;
}
$url_con = new Lib\Classes\Url(getCurrentUrl(), $fmw_database );
$fmw_serv_resp = $url_con->getUrlResp();


/*
if(!$default_value['is_config'] && $url == "/"){
    $url =  $default_value['site_url'].$default_value['config_dir'];
    header('Location: '.$url);
}

$database->setHostName($default_value['db_info']['host_name']);
$database->setUserName($default_value['db_info']['user_name']);
$database->setPassWord($default_value['db_info']['password']);

if($database->isConnection()){

    $Config = new Lib\Classes\Init\Config($database);

}else{
    echo "Please Check Your Database Access Information";
    exit;
}
*/
