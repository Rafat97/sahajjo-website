<?php
ob_start();
function base_url()
{
    $current_url = getCurrentUrl();
    $base_url = $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
    if($current_url != "/"){
        $base_url = str_replace($current_url,"",$base_url) . "/";
    }
    return $base_url;
}
function RootPath()
{
    $default_val = new Lib\Classes\Default_val();
    return $default_val->getRootPath()."/";
}
function GetStorePath()
{
    return RootPath()."stroage";
}
function defaultVal()
{
    $default_val = new Lib\Classes\Default_val();
    return $default_val->get_all_info();
}
function getCurrentUrl()
{
    $url = "";
    if(isset($_GET['url'] )){
        $url = "/".$_GET['url'];
    }
    else{
        $url = "/";
    }
    return $url;
}