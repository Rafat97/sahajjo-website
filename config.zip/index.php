<?php
session_start();



require_once __DIR__ . '/vendor/autoload.php';
include_once $fmw_serv_resp;
